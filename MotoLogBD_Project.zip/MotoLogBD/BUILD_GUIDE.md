# 📱 MotoLog BD — APK ও IPA বানানোর সম্পূর্ণ গাইড

এই প্রজেক্টটি **Capacitor** ব্যবহার করে বানানো — মানে একই কোড থেকে Android (.apk/.aab) এবং iOS (.ipa) দুটোই বানানো যাবে।

⚠️ **গুরুত্বপূর্ণ**: Apple-এর নিয়ম অনুযায়ী iOS অ্যাপ (.ipa) শুধুমাত্র **Mac কম্পিউটার + Xcode** দিয়েই বানানো সম্ভব — Windows/Linux দিয়ে না। নিচে Mac ছাড়া করার বিকল্প (Cloud Build) দেওয়া আছে।

---

## ✅ ধাপ ০: প্রস্তুতি (একবারই করবেন)

```bash
# প্রজেক্ট ফোল্ডারে যান
cd MotoLogBD

# Dependencies install করুন
npm install

# Web app বিল্ড করুন
npm run build
```

---

## 🤖 অংশ ১: Android APK বানানো (Windows/Mac/Linux — যেকোনো কম্পিউটারে)

### যা লাগবে:
- [Android Studio](https://developer.android.com/studio) (ফ্রি)
- Java JDK 17 (Android Studio-এর সাথেই আসে)

### ধাপসমূহ:

**1. Android প্রজেক্ট যোগ করুন** (প্রথমবার):
```bash
npx cap add android
npx cap sync android
```

**2. Android Studio-তে খুলুন**:
```bash
npx cap open android
```
এটি স্বয়ংক্রিয়ভাবে Android Studio খুলবে।

**3. APK বানান**:
- Android Studio-তে উপরের মেনু থেকে: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- বিল্ড শেষ হলে "locate" লিংকে ক্লিক করুন
- আপনার APK পাবেন: `android/app/build/outputs/apk/debug/app-debug.apk`

**4. Google Play-তে দেওয়ার জন্য (Signed Release APK)**:
- **Build → Generate Signed Bundle / APK**
- একটি নতুন **Keystore** বানান (এটি সংরক্ষণ করে রাখুন — ভবিষ্যতে আপডেটের জন্য দরকার হবে)
- **APK** বা **Android App Bundle (AAB)** সিলেক্ট করুন (Play Store-এ AAB লাগে)
- Release বিল্ড সম্পন্ন হবে

📌 **কোড পরিবর্তন করলে** পরের বার শুধু এই ৩টা কমান্ড দিন:
```bash
npm run build
npx cap sync android
npx cap open android
```

---

## 🍎 অংশ ২: iOS IPA বানানো

### অপশন A: নিজের Mac থাকলে (ফ্রি)

**যা লাগবে**: Mac কম্পিউটার + [Xcode](https://apps.apple.com/app/xcode) (ফ্রি) + Apple ID

```bash
npx cap add ios
npx cap sync ios
npx cap open ios
```

Xcode খুললে:
1. বাম পাশে project থেকে **Signing & Capabilities** ট্যাবে যান
2. আপনার Apple ID দিয়ে সাইন ইন করুন (Team সিলেক্ট করুন)
3. উপরে ডিভাইস/সিমুলেটর সিলেক্ট করে ▶️ (Run) চাপুন — নিজের আইফোনে টেস্ট করতে পারবেন
4. App Store-এ দেওয়ার জন্য: **Product → Archive** → **Distribute App**

⚠️ App Store-এ পাবলিশ করতে **Apple Developer Program** membership লাগবে ($99/বছর)।

### অপশন B: Mac না থাকলে (Cloud Build — সুপারিশকৃত)

Mac না থাকলে নিচের ফ্রি/সহজ সার্ভিসগুলো ব্যবহার করুন, এগুলো cloud-এ Mac ব্যবহার করে আপনার হয়ে বিল্ড করে দেয়:

1. **[Ionic Appflow](https://ionic.io/appflow)** — Capacitor প্রজেক্টের জন্য বিশেষভাবে বানানো, GitHub repo connect করে এক ক্লিকে APK+IPA বিল্ড
2. **[Codemagic](https://codemagic.io)** — ফ্রি টায়ার আছে, Capacitor/React সাপোর্ট করে
3. **GitHub Actions (macos runner)** — ফ্রি (public repo), কিন্তু নিজে CI script লিখতে হবে

**সহজ পদ্ধতি (Codemagic দিয়ে)**:
1. আপনার প্রজেক্ট GitHub-এ push করুন
2. [codemagic.io](https://codemagic.io)-তে সাইন আপ করে repo connect করুন
3. iOS workflow সিলেক্ট করুন, Apple Developer অ্যাকাউন্ট যুক্ত করুন
4. "Start Build" চাপুন — কিছুক্ষণ পর `.ipa` ফাইল ডাউনলোড করতে পারবেন

---

## 📲 অংশ ৩: টেস্টিং (স্টোরে না দিয়েই)

- **Android**: `app-debug.apk` ফাইলটি সরাসরি ফোনে পাঠিয়ে ইনস্টল করুন (Settings → Unknown Sources চালু করতে হবে)
- **iOS**: [TestFlight](https://developer.apple.com/testflight/) ব্যবহার করুন (Apple Developer Account লাগবে) — বন্ধু/পরীক্ষকদের লিংক পাঠাতে পারবেন

---

## 🏬 অংশ ৪: স্টোরে পাবলিশ করা

| প্ল্যাটফর্ম | প্রয়োজন | খরচ |
|---|---|---|
| Google Play Store | Google Play Console অ্যাকাউন্ট | এককালীন $25 |
| Apple App Store | Apple Developer Program | বছরে $99 |

দুই জায়গাতেই লাগবে:
- App আইকন (512x512 px, 1024x1024 px)
- Screenshots (কমপক্ষে ২-৩টা)
- Privacy Policy লিংক
- App বর্ণনা (বাংলা/ইংরেজি)

---

## 🎨 App আইকন ও Splash Screen বসানো

```bash
npm install @capacitor/assets --save-dev
```
তারপর `resources/icon.png` (1024x1024) এবং `resources/splash.png` (2732x2732) রাখুন এই কমান্ড চালান:
```bash
npx capacitor-assets generate
```
এটি স্বয়ংক্রিয়ভাবে সব সাইজের আইকন/স্প্ল্যাশ বানিয়ে Android ও iOS প্রজেক্টে বসিয়ে দেবে।

---

## ❓ সমস্যা হলে

| সমস্যা | সমাধান |
|---|---|
| `npx cap add android` কাজ করছে না | `npm install @capacitor/android` আগে চালান |
| Android Studio Gradle sync আটকে আছে | ইন্টারনেট কানেকশন চেক করুন, প্রথমবার সময় লাগে |
| Xcode "No signing certificate" দেখাচ্ছে | Apple ID দিয়ে Xcode-এ সাইন ইন করুন, Team সিলেক্ট করুন |
| App সাদা স্ক্রিন দেখাচ্ছে | `npm run build` চালিয়ে `npx cap sync` আবার করুন |

---

## 📝 সংক্ষেপে — সবচেয়ে সহজ পথ

```
Android (নিজে করুন, ফ্রি, ল্যাপটপ যেকোনো OS):
npm install → npm run build → npx cap add android → npx cap open android → Build APK

iOS (Mac থাকলে):
npm install → npm run build → npx cap add ios → npx cap open ios → Run/Archive

iOS (Mac না থাকলে):
GitHub-এ push করুন → Codemagic.io দিয়ে cloud build করুন
```

---

**তৈরি**: MotoLog BD প্রজেক্ট  
**Design by**: mijaN_ahmed
