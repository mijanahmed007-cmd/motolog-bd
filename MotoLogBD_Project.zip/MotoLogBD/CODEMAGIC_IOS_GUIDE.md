# 🍎 Codemagic দিয়ে iOS IPA বানানো (Mac ছাড়াই) — সম্পূর্ণ গাইড

## ✅ যা যা লাগবে (আগে থেকে রেডি করে রাখুন)

1. **GitHub অ্যাকাউন্ট** (ফ্রি)
2. **Apple ID** (সাধারণ আইফোন Apple ID হলেই চলবে প্রথমে)
3. **Apple Developer Program membership** ($99/বছর) — App Store বা TestFlight-এ দিতে হলে বাধ্যতামূলক। শুধু বিল্ড হচ্ছে কিনা টেস্ট করতে চাইলে এটা এখনই না করলেও চলবে (নিচে নোট দেখুন)
4. **Codemagic অ্যাকাউন্ট** (ফ্রি টায়ার — মাসে ৫০০ বিল্ড মিনিট)

---

## ধাপ ১: প্রজেক্ট GitHub-এ আপলোড করুন

```bash
cd MotoLogBD
git init
git add .
git commit -m "MotoLog BD - initial commit"
git branch -M main
git remote add origin https://github.com/আপনার-username/motolog-bd.git
git push -u origin main
```

কোড না লিখে করতে চাইলে: [GitHub Desktop](https://desktop.github.com) অ্যাপ ইনস্টল করুন → ফোল্ডার add করুন → "Publish repository" চাপুন।

---

## ধাপ ২: Codemagic-এ Repo যুক্ত করুন

1. [codemagic.io](https://codemagic.io) → **"Sign up with GitHub"**
2. Dashboard-এ **"Add application"** চাপুন
3. আপনার `motolog-bd` repository সিলেক্ট করুন
4. Project type হিসেবে **"Other"** বা **"Capacitor"** সিলেক্ট করুন (থাকলে)
5. এটি স্বয়ংক্রিয়ভাবে প্রজেক্টে থাকা **`codemagic.yaml`** ফাইলটা শনাক্ত করে নেবে (এই ফাইলটা আমি প্রজেক্টে যোগ করে দিয়েছি)

---

## ধাপ ৩: Apple সাইনিং সেটআপ (সবচেয়ে গুরুত্বপূর্ণ ধাপ)

Codemagic dashboard-এ:

1. বাম পাশে **Teams → Integrations → Apple Developer Portal** এ যান
2. **"Connect"** চাপুন
3. **App Store Connect API Key** বানাতে হবে:
   - [appstoreconnect.apple.com](https://appstoreconnect.apple.com) → Users and Access → Keys ট্যাব
   - **"Generate API Key"** চাপুন (Admin access লাগবে)
   - `.p8` ফাইল, **Key ID**, এবং **Issuer ID** — এই তিনটা Codemagic-এ পেস্ট করুন
4. এবার `codemagic.yaml`-এ যে `ios_signing` group আছে, সেখানে গিয়ে এই integration যুক্ত করে দিন (Codemagic UI নিজেই দেখিয়ে দেবে কীভাবে)

📌 **শুধু টেস্ট করতে চাইলে** (App Store-এ না দিয়ে): Apple Developer Program membership ছাড়াই Codemagic-এর "Automatic signing (Free Apple ID)" অপশন দিয়ে একটা সাধারণ Apple ID দিয়েও ৭ দিনের জন্য বৈধ টেস্ট বিল্ড বানানো যায় (Xcode-এর ফ্রি provisioning-এর মতো)।

---

## ধাপ ৪: Build চালানো

1. Codemagic dashboard-এ আপনার app-এ যান
2. **Workflow** হিসেবে `ios-capacitor-workflow` সিলেক্ট করুন (এটা `codemagic.yaml`-এ সংজ্ঞায়িত করা আছে)
3. **"Start new build"** চাপুন
4. Build log-এ দেখতে পারবেন প্রতিটা ধাপ কী হচ্ছে (npm install → build → pod install → Xcode archive)
5. সাধারণত **৫-১৫ মিনিট** সময় লাগে
6. সফল হলে **"Artifacts"** সেকশনে `.ipa` ফাইল পাবেন — ডাউনলোড করুন

---

## ধাপ ৫: ফোনে ইনস্টল করা

`.ipa` ফাইল সরাসরি ইনস্টল করা একটু জটিল (Apple-এর নিয়ম কড়া)। সহজ উপায়:

- **TestFlight** ব্যবহার করুন: `codemagic.yaml`-এ থাকা `submit_to_testflight: true` লাইনটা uncomment করে দিলে বিল্ড শেষে স্বয়ংক্রিয়ভাবে TestFlight-এ চলে যাবে, সেখান থেকে আপনার আইফোনে TestFlight অ্যাপ দিয়ে ইনস্টল করতে পারবেন
- অথবা **Diawi.com** / **Appetize.io** তে ম্যানুয়ালি আপলোড করে লিংক শেয়ার করতে পারেন (স্বল্পমেয়াদী টেস্টের জন্য)

---

## ⚠️ সাধারণ সমস্যা ও সমাধান

| সমস্যা | সমাধান |
|---|---|
| "No matching provisioning profile" | Apple Developer Portal integration ঠিকভাবে connect হয়নি, আবার চেষ্টা করুন |
| "pod install failed" | `ios/App/Podfile` ঠিক আছে কিনা দেখুন, `npx cap sync ios` আবার চালান |
| Build অনেকক্ষণ ধরে আটকে আছে | ফ্রি টায়ারে queue থাকতে পারে, একটু অপেক্ষা করুন |
| Bundle ID mismatch | Apple Developer Portal-এ App ID (`com.mijanahmed.motologbd`) রেজিস্টার করা আছে কিনা চেক করুন |

---

## 💰 খরচের হিসাব

| জিনিস | খরচ | কখন লাগবে |
|---|---|---|
| GitHub | ফ্রি | সবসময় |
| Codemagic ফ্রি টায়ার | ফ্রি (৫০০ মিনিট/মাস) | সাধারণ ব্যবহারে যথেষ্ট |
| Apple Developer Program | $99/বছর | App Store-এ পাবলিশ বা TestFlight-এ দিতে হলে |

---

**তৈরি**: MotoLog BD প্রজেক্ট  
**Design by**: mijaN_ahmed
